# CDR Analyzer

**Call Detail Record Analysis Tool for Cybercrime Investigations**

> Author: [Aniket Jha](https://linkedin.com/in/aniket-jha-4a626129a) — IFSO Special Cell, Delhi Police

---

## What it does

Analyses CDR (Call Detail Records) obtained from TSPs to:
- 📞 **Top Contacts** — most frequently called/received numbers with duration
- 📱 **IMEI Device Mapping** — all devices linked to a SIM (detects SIM swap / device exchange)
- 🗼 **Cell Tower Analysis** — geographic movement of suspect
- 🔗 **Link Analysis** — common contacts between two suspects
- 🌡️ **Activity Heatmap** — hour × day call pattern (shows active hours)
- 📊 **Excel Investigation Report** — multi-sheet with embedded charts

---

## Installation

```bash
pip install -r requirements.txt
```

---

## Usage

```bash
# Run with sample data
python cdr_analyzer.py --sample

# Analyse a suspect's CDR
python cdr_analyzer.py --input cdr.csv --suspect 9876543210 --fir 123/2026

# Link analysis (two suspects)
python cdr_analyzer.py --input cdr.csv --suspect 9876543210 --link 9123456789 --fir 123/2026

# Custom output directory
python cdr_analyzer.py --input cdr.csv --suspect 9876543210 --output reports/
```

---

## Input CSV Format

Flexible column detection. Supported names:

| Required | Optional |
|----------|----------|
| calling_no / a_party / caller | date, time |
| called_no / b_party / called | duration / duration_sec |
| | imei / imei_number |
| | tower / cell_id / cell_tower |
| | type / direction |

---

## Output

```
output/
├── CDR_Analysis_123_2026.xlsx     ← Full report (6 sheets)
├── heatmap_123_2026.png           ← Activity heatmap
├── top_contacts_123_2026.png      ← Bar chart
└── sample_cdr.csv                 ← (if --sample used)
```

### Excel Sheets
1. **Top Contacts** — frequency + duration
2. **IMEI Devices** — linked devices with timeline
3. **Tower Activity** — cell tower hit counts
4. **Full CDR** — complete raw records
5. **Link Analysis** — common contacts (if --link used)
6. **Charts** — embedded graph images

---

## Requirements

```
pandas
openpyxl
matplotlib
numpy
```

---

## Author

**Aniket Jha** | Cybercrime Investigator, IFSO Special Cell, Delhi Police  
📧 aniketjha395@gmail.com | 🔗 [LinkedIn](https://linkedin.com/in/aniket-jha-4a626129a)
