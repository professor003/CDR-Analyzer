#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║   CDR ANALYZER                                              ║
║   Call Detail Record Analysis Tool for Cybercrime IOs       ║
║   Author: Aniket Jha | IFSO Special Cell, Delhi Police      ║
║   GitHub: github.com/professor003                           ║
╚══════════════════════════════════════════════════════════════╝

Analyses Call Detail Records (CDR) to:
  • Identify most frequently contacted numbers
  • Build call timeline (activity heatmap)
  • Detect common callers between two suspects (link analysis)
  • Extract IMEI devices linked to a SIM
  • Map cell tower locations
  • Export full Excel investigation report + charts

Input CSV columns (flexible, auto-detected):
  date/time, calling_no, called_no, duration, imei, cell_id/tower, direction
"""

import sys
import os
import argparse
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from openpyxl.drawing.image import Image as XLImage
from datetime import datetime
from collections import Counter, defaultdict

BANNER = """
╔══════════════════════════════════════════════════════════════════╗
║     CDR ANALYZER  v1.0.0                                       ║
║     Call Detail Record Analysis for Cybercrime Investigations   ║
║     github.com/professor003/CDRAnalyzer                         ║
╚══════════════════════════════════════════════════════════════════╝
"""


def load_cdr(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = [c.strip().lower().replace(" ", "_") for c in df.columns]

    renames = {
        "calling_number":  "calling_no",
        "caller":          "calling_no",
        "a_party":         "calling_no",
        "called_number":   "called_no",
        "called":          "called_no",
        "b_party":         "called_no",
        "call_date":       "date",
        "call_time":       "time",
        "call_duration":   "duration",
        "duration_sec":    "duration",
        "imei_number":     "imei",
        "cell_id":         "tower",
        "cell_tower":      "tower",
        "tower_id":        "tower",
        "call_type":       "type",
        "direction":       "type",
    }
    df.rename(columns={k: v for k, v in renames.items() if k in df.columns}, inplace=True)

    # Parse datetime
    if "date" in df.columns and "time" in df.columns:
        df["datetime"] = pd.to_datetime(
            df["date"].astype(str) + " " + df["time"].astype(str),
            dayfirst=True, errors="coerce"
        )
    elif "date" in df.columns:
        df["datetime"] = pd.to_datetime(df["date"], dayfirst=True, errors="coerce")
    else:
        df["datetime"] = pd.NaT

    if "duration" in df.columns:
        df["duration"] = pd.to_numeric(df["duration"], errors="coerce").fillna(0)

    for col in ["calling_no", "called_no"]:
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip().str.replace(r"\D", "", regex=True)

    return df


def generate_sample_cdr(path: str):
    """Generate realistic sample CDR for testing."""
    import random
    from datetime import timedelta

    rows = []
    suspect = "9876543210"
    associate1 = "9123456789"
    associate2 = "9999988888"
    victim1 = "9111122222"
    victim2 = "9333344444"
    numbers = [associate1, associate2, victim1, victim2,
               "9555566666", "9777788888", "9000011111"]
    imeis = ["358612090123456", "357843091234567", "358612090123456"]
    towers = ["TOWER_DEL_001", "TOWER_DEL_002", "TOWER_GGN_001",
              "TOWER_NOI_001", "TOWER_DEL_003"]
    types = ["OUTGOING", "INCOMING", "OUTGOING", "OUTGOING", "INCOMING"]

    base = datetime(2026, 1, 15, 8, 0, 0)
    for i in range(120):
        dt = base + timedelta(hours=random.randint(0, 23*10), minutes=random.randint(0, 59))
        called = random.choice(numbers)
        direction = random.choice(types)
        calling = suspect if direction == "OUTGOING" else called
        called_n = called if direction == "OUTGOING" else suspect
        rows.append({
            "date": dt.strftime("%d/%m/%Y"),
            "time": dt.strftime("%H:%M:%S"),
            "calling_no": calling,
            "called_no": called_n,
            "duration": random.randint(5, 480),
            "type": direction,
            "imei": random.choice(imeis),
            "tower": random.choice(towers),
        })

    pd.DataFrame(rows).to_csv(path, index=False)
    print(f"  📄 Sample CDR created → {path} ({len(rows)} records)")


def top_contacts(df: pd.DataFrame, suspect_no: str, n: int = 20) -> pd.DataFrame:
    """Most frequently contacted numbers."""
    all_nos = pd.concat([
        df[df["calling_no"] == suspect_no]["called_no"],
        df[df["called_no"] == suspect_no]["calling_no"],
    ])
    counts = all_nos.value_counts().head(n).reset_index()
    counts.columns = ["Number", "Call Count"]
    if "duration" in df.columns:
        dur = defaultdict(float)
        for _, row in df.iterrows():
            other = row.get("called_no") if row.get("calling_no") == suspect_no else row.get("calling_no")
            if other:
                dur[other] += row.get("duration", 0)
        counts["Total Duration (sec)"] = counts["Number"].map(dur).fillna(0)
    return counts


def imei_devices(df: pd.DataFrame, suspect_no: str) -> pd.DataFrame:
    """All IMEI devices used by this SIM."""
    if "imei" not in df.columns:
        return pd.DataFrame(columns=["IMEI", "First Seen", "Last Seen", "Call Count"])
    mask = (df["calling_no"] == suspect_no) | (df["called_no"] == suspect_no)
    sub = df[mask]
    result = []
    for imei, grp in sub.groupby("imei"):
        result.append({
            "IMEI": imei,
            "First Seen": grp["datetime"].min() if "datetime" in grp else "",
            "Last Seen":  grp["datetime"].max() if "datetime" in grp else "",
            "Call Count": len(grp),
        })
    return pd.DataFrame(result).sort_values("Call Count", ascending=False)


def tower_activity(df: pd.DataFrame, suspect_no: str) -> pd.DataFrame:
    """Cell towers used by suspect SIM."""
    if "tower" not in df.columns:
        return pd.DataFrame(columns=["Tower ID", "Hit Count"])
    mask = (df["calling_no"] == suspect_no) | (df["called_no"] == suspect_no)
    tc = df[mask]["tower"].value_counts().reset_index()
    tc.columns = ["Tower ID", "Hit Count"]
    return tc


def hourly_heatmap(df: pd.DataFrame, suspect_no: str, out_path: str):
    """Activity heatmap: day of week × hour of day."""
    if "datetime" not in df.columns or df["datetime"].isna().all():
        return None
    mask = (df["calling_no"] == suspect_no) | (df["called_no"] == suspect_no)
    sub = df[mask].dropna(subset=["datetime"])
    if sub.empty:
        return None

    sub = sub.copy()
    sub["hour"] = sub["datetime"].dt.hour
    sub["dow"]  = sub["datetime"].dt.dayofweek   # 0=Mon

    grid = np.zeros((7, 24))
    for _, row in sub.iterrows():
        grid[int(row["dow"]), int(row["hour"])] += 1

    fig, ax = plt.subplots(figsize=(14, 5), facecolor="#1A1A2E")
    ax.set_facecolor("#1A1A2E")
    im = ax.imshow(grid, cmap="YlOrRd", aspect="auto")
    plt.colorbar(im, ax=ax, label="Call Count")
    ax.set_xticks(range(24))
    ax.set_xticklabels([f"{h:02d}:00" for h in range(24)],
                       rotation=45, color="white", fontsize=7)
    days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    ax.set_yticks(range(7))
    ax.set_yticklabels(days, color="white")
    ax.set_title(f"Call Activity Heatmap — {suspect_no}", color="white",
                 fontsize=12, fontweight="bold")
    ax.tick_params(colors="white")
    plt.tight_layout()
    plt.savefig(out_path, dpi=130, bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close()
    return out_path


def top_contacts_chart(contacts: pd.DataFrame, out_path: str, suspect_no: str):
    top = contacts.head(15)
    if top.empty:
        return None
    fig, ax = plt.subplots(figsize=(10, 6), facecolor="#1A1A2E")
    ax.set_facecolor("#1A1A2E")
    bars = ax.barh(top["Number"].astype(str)[::-1],
                   top["Call Count"][::-1], color="#E67E22")
    ax.set_xlabel("Call Count", color="white")
    ax.set_title(f"Top Contacts — {suspect_no}", color="white",
                 fontsize=12, fontweight="bold")
    ax.tick_params(colors="white")
    for spine in ax.spines.values():
        spine.set_edgecolor("#333333")
    for bar, val in zip(bars, top["Call Count"][::-1]):
        ax.text(bar.get_width() + 0.2, bar.get_y() + bar.get_height()/2,
                str(val), va="center", color="white", fontsize=9)
    plt.tight_layout()
    plt.savefig(out_path, dpi=130, bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close()
    return out_path


def common_contacts(df: pd.DataFrame, no1: str, no2: str) -> list:
    """Numbers that appear in BOTH suspects' CDR — link analysis."""
    def contacts_of(n):
        out = set(df[df["calling_no"] == n]["called_no"].tolist())
        inc = set(df[df["called_no"] == n]["calling_no"].tolist())
        return (out | inc) - {n}

    c1 = contacts_of(no1)
    c2 = contacts_of(no2)
    return list(c1 & c2)


def export_excel(df, contacts, imeis, towers, suspect_no, chains_common,
                 heatmap_path, contacts_chart_path, out_path, fir_no=""):
    wb = Workbook()
    hdr_fill = PatternFill("solid", fgColor="0D1F3C")
    hdr_font = Font(bold=True, color="FFFFFF", name="Arial", size=11)

    def sheet(ws, title_text):
        ws.merge_cells(f"A1:{get_column_letter(ws.max_column or 8)}1")
        ws["A1"] = title_text
        ws["A1"].font = Font(bold=True, size=12, color="0D1F3C", name="Arial")
        ws["A1"].alignment = Alignment(horizontal="center")
        ws.append([])

    def write_df(ws, dataframe, col_ws=20):
        ws.append(list(dataframe.columns))
        for cell in ws[ws.max_row]:
            cell.fill = hdr_fill; cell.font = hdr_font
            cell.alignment = Alignment(horizontal="center")
        for _, row in dataframe.iterrows():
            ws.append([str(v) if pd.notna(v) else "" for v in row])
        for col in range(1, len(dataframe.columns) + 1):
            ws.column_dimensions[get_column_letter(col)].width = col_ws

    # Sheet 1: Top Contacts
    ws1 = wb.active; ws1.title = "Top Contacts"
    ws1["A1"] = f"TOP CONTACTS — {suspect_no} — FIR: {fir_no}"
    ws1["A1"].font = Font(bold=True, size=13, color="0D1F3C", name="Arial")
    ws1.append([])
    write_df(ws1, contacts)

    # Sheet 2: IMEI Devices
    ws2 = wb.create_sheet("IMEI Devices")
    ws2["A1"] = f"IMEI DEVICES LINKED TO {suspect_no}"
    ws2["A1"].font = Font(bold=True, size=13, color="0D1F3C", name="Arial")
    ws2.append([])
    write_df(ws2, imeis)

    # Sheet 3: Tower Activity
    ws3 = wb.create_sheet("Tower Activity")
    ws3["A1"] = f"CELL TOWER USAGE — {suspect_no}"
    ws3["A1"].font = Font(bold=True, size=13, color="0D1F3C", name="Arial")
    ws3.append([])
    write_df(ws3, towers)

    # Sheet 4: Full CDR
    ws4 = wb.create_sheet("Full CDR")
    ws4["A1"] = "COMPLETE CALL DETAIL RECORDS"
    ws4["A1"].font = Font(bold=True, size=13, color="0D1F3C", name="Arial")
    ws4.append([])
    write_df(ws4, df[[c for c in df.columns if c != "datetime"]])

    # Sheet 5: Common Contacts (link analysis)
    if chains_common:
        ws5 = wb.create_sheet("Link Analysis")
        ws5["A1"] = "COMMON CONTACTS (Link Analysis)"
        ws5["A1"].font = Font(bold=True, size=13, color="0D1F3C", name="Arial")
        ws5.append([])
        ws5.append(["Common Number"])
        for cell in ws5[ws5.max_row]:
            cell.fill = hdr_fill; cell.font = hdr_font
        for n in chains_common:
            ws5.append([n])

    # Sheet 6: Charts
    ws6 = wb.create_sheet("Charts")
    ws6["A1"] = "CDR ANALYSIS CHARTS"
    ws6["A1"].font = Font(bold=True, size=13, color="0D1F3C", name="Arial")
    row_offset = 3
    for img_path, label in [(heatmap_path, "Activity Heatmap"),
                             (contacts_chart_path, "Top Contacts")]:
        if img_path and os.path.exists(img_path):
            ws6.cell(row=row_offset, column=1, value=label).font = Font(bold=True, name="Arial")
            img = XLImage(img_path)
            img.anchor = f"A{row_offset + 1}"
            ws6.add_image(img)
            row_offset += 30

    wb.save(out_path)
    print(f"  📋 Excel report → {out_path}")


def main():
    print(BANNER)
    parser = argparse.ArgumentParser(description="CDR Analyzer")
    parser.add_argument("--input",   "-i", help="CDR CSV file path")
    parser.add_argument("--suspect", "-s", help="Suspect mobile number to analyse")
    parser.add_argument("--link",    "-l", help="Second suspect number for link analysis")
    parser.add_argument("--fir",     "-f", default="", help="FIR Number")
    parser.add_argument("--output",  "-o", default="output", help="Output directory")
    parser.add_argument("--sample",        action="store_true", help="Generate sample and run demo")
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)

    if args.sample:
        sample_path = os.path.join(args.output, "sample_cdr.csv")
        generate_sample_cdr(sample_path)
        args.input   = sample_path
        args.suspect = "9876543210"
        args.link    = "9123456789"
        args.fir     = "SAMPLE/2026"

    if not args.input or not args.suspect:
        print("Usage: python cdr_analyzer.py --input cdr.csv --suspect 9876543210 --fir 123/2026")
        print("       python cdr_analyzer.py --sample")
        sys.exit(0)

    print(f"  📥 Loading CDR: {args.input}")
    df = load_cdr(args.input)
    print(f"  ✅ {len(df)} records loaded")

    suspect = args.suspect.strip()
    mask = (df.get("calling_no", pd.Series(dtype=str)) == suspect) | \
           (df.get("called_no",  pd.Series(dtype=str)) == suspect)
    suspect_rows = df[mask]
    print(f"  📞 Records for {suspect}: {len(suspect_rows)}")

    print("  🔍 Analysing top contacts...")
    contacts = top_contacts(df, suspect)
    print(f"  ✅ Top {len(contacts)} contacts identified")

    print("  📱 Extracting IMEI devices...")
    imeis = imei_devices(df, suspect)
    if not imeis.empty:
        print(f"  ✅ {len(imeis)} unique IMEI(s) found")
        for _, r in imeis.iterrows():
            print(f"     IMEI: {r['IMEI']}  |  Calls: {r['Call Count']}")

    print("  🗼 Analysing tower usage...")
    towers = tower_activity(df, suspect)

    # Link analysis
    common = []
    if args.link:
        common = common_contacts(df, suspect, args.link)
        if common:
            print(f"\n  🔗 Link Analysis — Common contacts between {suspect} and {args.link}:")
            for n in common:
                print(f"     {n}")
        else:
            print(f"  ℹ️  No common contacts between {suspect} and {args.link}")

    # Charts
    tag = args.fir.replace("/", "_") if args.fir else suspect
    heat_path    = os.path.join(args.output, f"heatmap_{tag}.png")
    chart_path   = os.path.join(args.output, f"top_contacts_{tag}.png")
    excel_path   = os.path.join(args.output, f"CDR_Analysis_{tag}.xlsx")

    print("  🎨 Generating charts...")
    h = hourly_heatmap(df, suspect, heat_path)
    c = top_contacts_chart(contacts, chart_path, suspect)

    print("  📊 Exporting Excel report...")
    export_excel(df, contacts, imeis, towers, suspect,
                 common, h, c, excel_path, args.fir)

    print(f"\n  ✅ Analysis complete. Check '{args.output}/' folder.\n")


if __name__ == "__main__":
    main()
